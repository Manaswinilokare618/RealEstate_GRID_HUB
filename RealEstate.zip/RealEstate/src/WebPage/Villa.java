package WebPage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Villa {
	
	WebDriver dr;
	
	
	//*[@id="ajaxsearchlite1"]/div/div[3]/form/input[1]
	By ser= By.xpath("//*[@id='ajaxsearchlite1']/div/div[3]/form/input[1]");
	
	
	//*[@id="mCSBap_1_container"]/div/div[1]/div[1]/h3/a
	By nall= By.xpath("//*[@id='mCSBap_1_container']/div/div[1]/div[1]/h3/a");
	
	
	//*[@id="wpcf7-f4-o1"]/form/p[1]/label/span/input
	
	//#wpcf7-f4-o1 > form > p:nth-child(2) > label > span > input
	By name= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[1]/label/span/input");
	
	//*[@id="wpcf7-f4-o1"]/form/p[2]/label/span/input
	By email= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[2]/label/span/input");
	
	//*[@id="wpcf7-f4-o1"]/form/p[3]/label/span/input
	By subject= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[3]/label/span/input");
	
;	//*[@id="wpcf7-f4-o1"]/form/p[4]/label/span/textarea
	By area= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[4]/label/span/textarea");
	
	//*[@id="wpcf7-f4-o1"]/form/p[5]/input
	By send= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[5]/input");
	
	//*[@id="wpcf7-f4-o1"]/form/div[2]
	By msg= By.xpath("//*[@id='wpcf7-f4-o1']/form/div[2]");

	
	public Villa(WebDriver dr)
	{
		this.dr=dr;
	}
	public void set_search(String s)
	{
		dr.findElement(ser).sendKeys(s);
	}
	
	
	public void select_nall()
	{
		dr.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		dr.findElement(nall).click();
	}
	
	public void set_name(String s)
	{
		WebDriverWait wt= new WebDriverWait(dr,40);
		wt.until(ExpectedConditions.presenceOfElementLocated(name));
		
		dr.findElement(name).sendKeys(s);
	}
	
	public void set_email(String s)
	{
		dr.findElement(email).sendKeys(s);
	}
	public void set_subject(String s)
	{
		dr.findElement(subject).sendKeys(s);
	}
	public void set_msg(String s)
	{
		dr.findElement(area).sendKeys(s);
	}
	public void click_send()
	{
		dr.findElement(send).click();
	}
	public String getmsg()
	{
		return dr.findElement(msg).getText();
	}
	
	public void do_search(String a,String b,String c,String d)
	{
		set_search("Nullam hendrerit apartment");
		select_nall();
		set_name(a);
		set_email(b);
		set_subject(c);
		set_msg(d);
		click_send();
	}
	
}
