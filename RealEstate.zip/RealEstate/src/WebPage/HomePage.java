package WebPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	
	WebDriver dr;
	
	By logo= By.xpath("//*[@id='post-133']/div[1]/div/div/ul[2]/li[2]/a");
	
	By villa=By.xpath("//*[@id='menu-item-571']/a");
	
	public HomePage(WebDriver dr)
	{
		this.dr= dr;
	
	}
	
	public void logout()
	{
		 dr.findElement(logo).click();
	}
	public void click_villa()
	{
		dr.findElement(villa).click();
	}

}
