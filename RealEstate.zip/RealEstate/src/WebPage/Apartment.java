package WebPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Apartment {
	
	WebDriver dr;
	
	
	//*[@id="wrapper"]/div[3]/div[2]/div/div/div[2]/div/div[4]/div/a/div[2]/span
	By quist= By.xpath("//*[@id='wrapper']/div[3]/div[2]/div/div/div[2]/div/div[4]/div/a/div[2]/span");
	
	//*[@id="wpcf7-f4-o1"]/form/p[1]/label/span/input
	By name= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[1]/label/span/input");
	By email= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[2]/label/span/input");
	By subject= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[3]/label/span/input");
	By message= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[4]/label/span/textarea");
	By send= By.xpath("//*[@id='wpcf7-f4-o1']/form/p[5]/input");
	
	By mas= By.xpath("//*[@id='wpcf7-f4-o1']/form/div[2]");

	//*[@id="amount"]
	
	By sp= By.xpath("//*[@id='amount']");
	//*[@id="downpayment"]
	By dp= By.xpath("//*[@id='downpayment']");
	//*[@id="years"]
	By year= By.xpath("//*[@id='years']");
	//*[@id="interest"]
	By irate= By.xpath("//*[@id='interest']");
	//button calc-button
	//*[@id="widget_mortgage_calc_properties-4"]/form/button
	By cal= By.xpath("//*[@id='widget_mortgage_calc_properties-4']/form/button");
	//*[@id="widget_mortgage_calc_properties-4"]/form/div[5]/div/strong
	//calc-output
	By result= By.className("calc-output");
	//By result= By.xpath("//*[@id='widget_mortgage_calc_properties-4']/form/div[5]/div/strong");
	By street= By.xpath("//*[@id='keyword_search']");
	
	//*[@id="_property_type_chosen"]/a
	//*[@id="_property_type_chosen"]/a/span
	By proper= By.xpath("//*[@id='_property_type_chosen']/a/span[text()='Plots']");

	
	//*[@id="realteo-search-form"]/div[2]/div[2]/div/div/div/input
	By region= By.xpath("//*[@id='realteo-search-form']/div[2]/div[2]/div/div/div/input");
	//*[@id="realteo-search-form"]/div[3]/div/button
	By search= By.xpath("//*[@id='realteo-search-form']/div[3]/div/button");
	public Apartment(WebDriver dr)
	{
		this.dr= dr;
	}
	public void click_qiust()
	{
		dr.findElement(quist).click();
	}
	public void set_name(String nm)
	{
		dr.findElement(name).sendKeys(nm);

	}
	public void set_email(String nm)
	{
		dr.findElement(email).sendKeys(nm);

	}
	public void set_subject(String nm)
	{
		dr.findElement(subject).sendKeys(nm);

	}
	public void set_message(String nm)
	{
		dr.findElement(message).sendKeys(nm);

	}
	public void click_send()
	{
		dr.findElement(send).click();

	}
	public String Message_after_send()
	{
		
		return dr.findElement(mas).getText();
	}
	public void send_enquiry(String nm, String em, String sub, String msg)
	{
		click_qiust();
		set_name(nm);
		set_email(em);
		set_subject(sub);
		set_message(msg);
		click_send();
		
	}
	public void set_sale_price(String sp1)
	{
		dr.findElement(sp).sendKeys(sp1);
	}
	public void set_down_payment(String dp1)
	{
		dr.findElement(dp).sendKeys(dp1);
	}
	public void set_loan_year(String year1)
	{
		dr.findElement(year).sendKeys(year1);
	}
	public void set_interest_rate(String rate)
	{
		dr.findElement(irate).sendKeys(rate);
	}
	public void click_calculate()
	{
		dr.findElement(cal).click();
	}

	public void calculate(String nm, String em, String sub, String msg)
	{
		click_qiust();
		set_sale_price(nm);
		set_down_payment(em);
		set_loan_year(sub);
		set_interest_rate(msg);
		click_calculate();
	}
	public String getresult()
	{
		WebDriverWait wt= new WebDriverWait(dr,10);
		wt.until(ExpectedConditions.presenceOfElementLocated(result));
		
		return dr.findElement(result).getText();
	}
	
	public void set_street(String str)
	{
		dr.findElement(street).sendKeys(str);
		//Select select = new Select(dr.findElement(street));
		//select.selectByVisibleText(str);
		
		
		
	}
	public void select_property()
	{
		
		dr.findElement(proper).click();
		
		
	}
	public void select_Region(String c)
	{
		dr.findElement(By.xpath("//*[@id='realteo-search-form']/div[2]/div[2]/div/a/div")).click();
		dr.findElement(region).sendKeys(c);

	}
	public void click_search()
	{
		dr.findElement(search).click();

	}
	public void search1(String a,String b)
	{
		set_street(a);
		//select_property();
		select_Region(b);
		click_search();
	}
	public String after_serch()
	{
		return dr.getTitle();
	}

}
