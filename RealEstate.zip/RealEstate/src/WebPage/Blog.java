package WebPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Blog {
	
	WebDriver dr;
	
	////*[@id="menu-item-617"]/a
	By blog= By.xpath("//*[@id='menu-item-617']/a");
	//*[@id="text-4"]/div/div/p[2]/a
	
	//button fullwidth margin-top-20
	//*[@id="text-4"]/div/div/p[2]/a/i
	//*[@id="text-4"]/div/div/p[2]/a
	By drop= By.xpath("//*[@id='text-4']/div/div/p[2]/a");	
	
	//*[@id="wpcf7-f119-p134-o1"]/form/div[2]/div[1]/div/span/input
	By name= By.xpath("//*[@id='wpcf7-f119-p134-o1']/form/div[2]/div[1]/div/span/input");
	
	////*[@id="wpcf7-f119-p134-o1"]/form/div[2]/div[2]/div/span/input
	
	By email= By.xpath("//*[@id='wpcf7-f119-p134-o1']/form/div[2]/div[2]/div/span/input");
	
	//*[@id="wpcf7-f119-p134-o1"]/form/div[2]/div[3]/div/span/input
	By sub= By.xpath("//*[@id='wpcf7-f119-p134-o1']/form/div[2]/div[3]/div/span/input");
	
	//*[@id="wpcf7-f119-p134-o1"]/form/div[3]/span/textarea
	By msg =By.xpath("//*[@id='wpcf7-f119-p134-o1']/form/div[3]/span/textarea");
	
	//*[@id="wpcf7-f119-p134-o1"]/form/p/input
	By send = By.xpath("//*[@id='wpcf7-f119-p134-o1']/form/p/input");
	
	public Blog(WebDriver dr)
	{
		this.dr= dr;
		
	}
		
	public void click_blog()
	{
		dr.findElement(blog).click();
	}
	public void click_drop()
	{
		dr.findElement(drop).click();
	}
	public void set_name(String s)
	{
		dr.findElement(name).sendKeys(s);
	}
	public void set_email(String s)
	{
		dr.findElement(email).sendKeys(s);
	}
	public void set_subject(String s)
	{
		dr.findElement(sub).sendKeys(s);
	}
	public void set_msg(String s)
	{
		dr.findElement(msg).sendKeys(s);
	}
	public void click_send()
	{
		dr.findElement(send).click();
	}
	public void send_line(String s,String s2,String s3,String s4)
	{
		click_blog();
		click_drop();
		set_name(s);
		set_email(s2);
		set_subject(s3);
		set_msg(s4);
		click_send();
	}
}
