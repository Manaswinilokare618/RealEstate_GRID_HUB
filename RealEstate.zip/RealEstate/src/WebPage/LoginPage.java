package WebPage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;



public class LoginPage 
{
	
    WebDriver dr;
	
	////*[@id="mm-2"]/ul/li[8]/a
    
  //*[@id="mm-2"]/ul/li[8]/a
	
	By log= By.className("sign-in");
	By username= By.xpath("//*[@id='user_login']");
	By pass= By.xpath("//*[@id='user_pass']");
	By signin= By.xpath("//*[@id='tab1']/form/p[3]/input");
	By Apart = By.xpath("//*[@id='menu-item-346']/a");
	
	public LoginPage(WebDriver dr)
	{
		this.dr=dr;
		
	}
	public void click_login()
	{
		dr.findElement(log).click();
	}
	public void set_uname(String un)
	{
		dr.findElement(username).sendKeys(un);
	}
	public void set_pwd(String ps)
	{
		dr.findElement(pass).sendKeys(ps);
	}
	public void click_btn(){
	
		dr.findElement(signin).click();
	}
	
	public void do_login(String u,String p)
	{
		this.click_login();
		this.set_uname(u);
		this.set_pwd(p);
		this.click_btn();
		
	}
	public String gettitle()
	{
		return dr.getTitle();
	}
	
	public void click_Apartment()
	{
		dr.findElement(Apart).click();
	}
}

	
	
	



