package TestRunNG;

import org.testng.annotations.Test;

import WebPage.Apartment;
import WebPage.HomePage;
import WebPage.LoginPage;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;

public class InternetexTN{
	
	WebDriver dr;
	String autURL, nodeURL;
	
	
	LoginPage lg;
	HomePage hp;
	Apartment ap;

	
  
  @BeforeMethod
  public void beforeMethod() throws MalformedURLException {
			
		  autURL="http://realestate.upskills.in/";
		  nodeURL="http://172.24.98.42:1996/wd/hub";
		  
		  
		  DesiredCapabilities cap=DesiredCapabilities.internetExplorer();
		  cap.setBrowserName("internet explorer");
		  cap.setPlatform(Platform.WINDOWS);
		  dr=new RemoteWebDriver(new URL(nodeURL),cap);
		  dr.get(autURL);

  }
  @Test
  public void Test6() 
  {
	  lg= new LoginPage(dr);
	  
	  hp= new HomePage(dr);
	  
	  lg.do_login("manaswinilokare618@gmail.com", "123Manaswi123#");
	  hp.logout();
	  
	  
	  
	  String actual_pn = lg.gettitle();
	  Assert.assertTrue(actual_pn.contains("My Profile � Real Estate"));
	  dr.close();
	  
	  
}
  @Test
  public void Test7() 
  {
	  lg= new LoginPage(dr);
	  ap= new Apartment(dr);
	  
	  lg.click_Apartment();
	  
	 ap.send_enquiry("manaswini", "manaswinilokare618@gmail.com", "apartment", "looking for apartment");
	 String as= ap.Message_after_send();
	 //System.out.println("text"+as);
	 
	 
	  Assert.assertTrue(as.contains("Thank you for your message.It has been send"));

	  dr.close();

	}
  @Test
  public void Test8() 
  {
	  lg= new LoginPage(dr);
	  ap= new Apartment(dr);
	  
	  lg.click_Apartment();
	  
	  ap.calculate("400000", "20000", "20", "7.25");
	  String as= ap.getresult();
		 System.out.println("text="+as);
	Assert.assertEquals(as, "3003.43 Rs.");
	dr.close();
  
  }
  

}
