package TestRunNG;

import org.testng.annotations.Test;

import WebPage.Apartment;
import WebPage.Blog;
import WebPage.HomePage;
import WebPage.LoginPage;
import WebPage.Villa;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
public class RealEstate {
  
	
	WebDriver dr;
	
	LoginPage lg;
	HomePage hp;
	Apartment ap;
	Villa v;
	Blog bg;
	
	
	@BeforeClass
  public void beforeClass()
	{
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");  
		dr= new ChromeDriver();
		dr.get("http://realestate.upskills.in/");
		
	 }
  
  
  
  public void Test6() 
  {
	  lg= new LoginPage(dr);
	  hp= new HomePage(dr);
	  
	  lg.do_login("manaswinilokare618@gmail.com", "123Manaswi123#");
	  hp.logout();
	  
	  
	  
	  String actual_pn = lg.gettitle();
	  Assert.assertTrue(actual_pn.contains("My Profile � Real Estate"));
	  
	  
}
  
  public void Test7() 
  {
	  lg= new LoginPage(dr);
	  ap= new Apartment(dr);
	  
	  lg.click_Apartment();
	  
	 ap.send_enquiry("manaswini", "manaswinilokare618@gmail.com", "apartment", "looking for apartment");
	 String as= ap.Message_after_send();
	 //System.out.println("text"+as);
	 
	 
	  Assert.assertTrue(as.contains("Thank you for your message.It has been send"));

	  

	}
  
  public void Test8() 
  {
	  lg= new LoginPage(dr);
	  ap= new Apartment(dr);
	  
	  lg.click_Apartment();
	  
	  ap.calculate("400000", "20000", "20", "7.25");
	  String as= ap.getresult();
		 System.out.println("text="+as);
	Assert.assertEquals(as, "3003.43 Rs.");
 
  
  }
  
  public void Test9() 
  {
	  lg= new LoginPage(dr);
	  ap= new Apartment(dr);
	  
      lg.click_Apartment();
	  
      ap.search1("Electronic City, Bengaluru, Karnataka, India","  Central Bangalore");
      String as= ap.after_serch();
		 System.out.println("text="+as);

      
  }
   @Test
  public void Test10()
  {
	  bg= new Blog(dr);
	  bg.send_line("Manaswini", "manaswinilokare618@gmail.com", "Apartment", "Looking for apartment");
	  
	  
  }

  public void Test36()
  {
	  lg= new LoginPage(dr);
	  hp= new HomePage(dr);
	  v= new Villa(dr);
  
	  lg.do_login("manaswinilokare618@gmail.com", "123Manaswi123#");

	  hp.click_villa();
	  v.do_search("selenium", "selenuim@gmail.com","apartment", "looking for apartment");
	  String act=v.getmsg();
	  System.out.println(act);
	  Assert.assertTrue(act.contains("Thank you for your message.It has been send"));

	  
	  	  
  }
  //@Test
  public void Test37()
  {
	  
  }
  
  }